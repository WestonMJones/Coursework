<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Login Page</title> 
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="Weston Jones"> 

  
  </head>

  <body>

    



    <form action="login_action.php" method="post">
      Username: <input type="text" name="name"><br>
      Password: <input type="text" name="pass"><br>
      <input type="submit">
    </form>



  </body>
  
</html>