<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Register Page</title> 
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="Weston Jones"> 

  	
  </head>

  <body>

    



    <form action="reg_action.php" method="post">
      Username: <input type="text" name="uname"><br>
      First Name: <input type="text" name="fname"><br>
      Last Name: <input type="text" name="lname"><br>
      Nick Name: <input type="text" name="nname"><br>
      Password: <input type="text" name="pass"><br>

      <input type="submit">
    </form>



  </body>

  
  
</html>