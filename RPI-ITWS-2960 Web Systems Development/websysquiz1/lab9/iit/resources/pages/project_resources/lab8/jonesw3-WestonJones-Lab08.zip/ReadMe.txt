THis was a simple and straightforward lab.

I liked the use of XSS attacks to demonstrate
some of the tricker sides of javascript and raise
some concerns for us as we add functionality to our websites

Link to Website: https://afsws.rpi.edu/AFS/home/08/jonesw3/public_html/iit/resources/pages/project_resources/lab8/lab8.html#