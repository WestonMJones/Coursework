This was a somewhat frustrating lab to complete. I couldn't get the AJAX to run on my local machine no matter what I did, so to test things I had
to upload everything to RPI's server. This meant it took a lot of time between tests, which was really annoying since we had no IDE to validate the syntax of our javascript.

I also had to figure out that my browser was caching everything which further delayed testing. :(

Once I finally got the AJAX to work, I had it generate HTML that was consistent with the aesthetic of my website.

I used a smaller heading (h2) for the lab titles and simple p-tags for the descriptions / links.

The simple yet professional format, combined with the title page and glowy navigation icons gives my website a look I'm happy with.

Link to dynamically generated projects page: https://afsws.rpi.edu/AFS/home/08/jonesw3/public_html/iit/resources/pages/projects.html#

My entire iit directory