<?php

$config = array(
   'DB_HOST'     => 'localhost',
   'DB_NAME'     => 'websyslab10',
   'DB_USERNAME' => 'thilanka',
   'DB_PASSWORD' => 'abc123',
);

?>