1) What are the advantages to writing a jQuery plugin over regular JavaScript that uses jQuery?

One of the main reasons are that it makes abstraction better when working with complex web applications




2) Explain how your jQuery plugin adheres to best practices in JavaScript and jQuery development.

At the beginning of jQuery plugin we declare the the global variables which makes the code easier and faster to understand. Binded event handlers to know when/what to do to certain elements update 





3) Does anything prevent you from POSTing high scores to a server on a different domain? If so, what? If not, how would we go about it (written explanation/pseudocode is fine here)?