## Question 1: 
### 

What are the advantages to writing a jQuery plugin over regular JavaScript that uses jQuery?

Creating jQuery plugins helps with portability and abstraction. Its akin to writing your own library for a language like Python. It can be used anywhere, installed anywhere, and makes it easy to reuse code.



## Question 2:
### Explain how your jQuery plugin adheres to best practices in JavaScript and jQuery development?



Our code has been linted to make it nice and readable, and the JavaScript and jQuery scripting and link tags are properly located in the HTML document as to adhere to typical web development standards.




## Question 3:
## Does anything prevent you from POSTing high scores to a server on a different domain? If so, what? If not, how would we go about it (written explanation/pseudocode is fine here)?

Nothing prevents us from doing that because we would simply use a jQuery/Ajax POST request to send the finalized score to a different webpage after the game has been completed. We did not do this because we didn't have time to complete the extra credit.