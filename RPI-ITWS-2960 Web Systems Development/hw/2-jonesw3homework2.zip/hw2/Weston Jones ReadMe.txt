Group Members:

Group 2:
Weston Jones
Daniel Schnoll
Jennifer Lee
Mark Robinson


We all submitted our readmes, but I (Weston Jones) submitted the finished code.


We were happy with the division of labor for this assignment.
We all wrote small functions / snippets of code that were later integrated into the finished assigment.


Questions:


1) What are the advantages to writing a jQuery plugin over regular JavaScript that uses jQuery?


	The way a plugin is called is helpful. Everytime the plugin is called it refreshes the page and resets all of its
	internal variables, since it is just a big function. This made it easy to implement the "new game" feature for our code.


2) Explain how your jQuery plugin adheres to best practices in JavaScript and jQuery development.


	All of our code is neatly indented, commented, linted. Our selectors are short and to the point, and we have proper scope
	on all of our variables. 


3) Does anything prevent you from POSTing high scores to a server on a different domain? If so, what? If
not, how would we go about it (written explanation/pseudocode is fine here)?

	No, we could use AJAX post requests if all else failed. 
