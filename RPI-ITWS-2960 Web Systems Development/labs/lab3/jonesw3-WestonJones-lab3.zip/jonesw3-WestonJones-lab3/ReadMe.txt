

This was a pretty straight forward lab.

For part 1 I wrote a basic recursive depth first search function that would properly generate the tree
Note that the string.repeat function I use to generate the correct amount of dashes doesn't work in internet explorer for some reason.


For part II, I added a few more lines of code to bind on click listeners to every element. The part II code is delineated from the part I code with comments.

When I click on a element I get a message printing the tags of the clicked element, then it's parent, then it's grandparent, and so on, illustrating the "bubble up" effect.

For part III, i used a selector to generate a list of divs, then I iterated through that list to bind the necessary event listeners.


The html and javascript files are all attached for you to see that the code works as intended, but I've included some screenshots as well.