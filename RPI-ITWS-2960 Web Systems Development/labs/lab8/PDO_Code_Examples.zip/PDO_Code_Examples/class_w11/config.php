<?php

$config = array(
   'DB_HOST'     => '127.0.0.1',
   'DB_USERNAME' => 'thilanka',
   'DB_PASSWORD' => 'abc123',
);

 ?>