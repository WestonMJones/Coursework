This was one of the more difficult labs to complete.

The first few parts of the assignment were somewhat tedious -- having to enter in lots of information to complete relatively simple
tasks. 

The last few parts that required use of joins were somewhat trickier and required a bit more thought.

Included is the text file commands which includes a list of all the commands I used to complete the lab.

ALso included is the text structure of my lab in the websyslab7 textfile