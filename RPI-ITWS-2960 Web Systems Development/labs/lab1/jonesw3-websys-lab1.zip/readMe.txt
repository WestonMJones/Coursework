This lab was fairly straightforward.

For part 1, I already had XAMPP installed from Intro to ITWS, so It was easy enough to turn on the server then navigate to phpmyadmin and take a screenshot.

For part 2, I added the lab1.websys virtual host and set the document root to
the lab1 dropbox folder I have for this class. I also made sure
"include httpd-vhosts" was uncommented in the httpd configuration file.

Then I edited the windows host file to resolve "lab1.websys" into the proper
address 

Included is the screenshot of phpmyAdmin for part 1, my vhosts configuration
file, my main httpd.conf configuration file, my windows host file, and
then the screenshot showing info about my php installation. 

