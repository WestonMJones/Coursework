<?php

	$config = array(
	   'DB_HOST'     => '127.0.0.1',
	   'DB_USERNAME' => 'root',
	   'DB_PASSWORD' => '73Weserrang',
	   'DB_NAME' => 'lab9',
	   'DB_COL' => 'utf8mb4'
	);


 

?>