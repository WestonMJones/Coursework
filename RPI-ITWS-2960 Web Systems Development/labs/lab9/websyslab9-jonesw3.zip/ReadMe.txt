The UI for this lab was a minimal focus since
most of lab dealt with interactions between the front and backend.

The login page perfors it's intended function of getting data
from a SQL database, but one can still just navigate past
the index page to the main page without logging in.

Obviously we wouldn't use such weak authentication for a real website.

You can change the username and password in the config file to demo the code on your machine without having to update the
credentials in every file.