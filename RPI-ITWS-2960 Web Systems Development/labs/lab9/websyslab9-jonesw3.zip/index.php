<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Lab 9</title> 
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="Weston Jones"> 

	<!-- CSS Include -->
  	<link rel="stylesheet" href="main.css">

  </head>

  <body>

	<div class="center">
		<h1>Lab 9 Login Page</h1>
		<form action="login_action.php" method="post">
	      Username: <input type="text" name="name"><br>
	      Password: <input type="text" name="pass"><br>
	      <input type="submit">
	    </form>
    </div>

        
  	

  </body>
  
</html>