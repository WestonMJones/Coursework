If the makefile doesn't work you can just compile with gcc

I didn't use any external non system libraries.