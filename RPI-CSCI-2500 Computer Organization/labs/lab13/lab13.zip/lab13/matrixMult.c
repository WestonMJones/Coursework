#include <stdio.h>
#include <time.h>
#include <stdlib.h>

#define n 1500

int main(int argc, char ** argv)
{
    int ** a;
    int ** b;
    int ** c;

    a = (int **) malloc(sizeof(int *)* n);
    b = (int **) malloc(sizeof(int *)* n);
    c = (int **) malloc(sizeof(int *)* n);

    for(int i = 0; i < n; i++) {
        a[i] = (int *) malloc(sizeof(int)*n);
        b[i] = (int *) malloc(sizeof(int)*n);
        c[i] = (int *) malloc(sizeof(int)*n);
    }

    for(int i = 0; i < n; i++) {
        for(int j = 0; j < n; j++) {
            c[i][j] = 0;
            a[i][j] = b[i][j] = i;
        }
    }

    time_t start1, end1;
    clock_t start2, end2;

    start1 = time(NULL);
    start2 = clock();

    /**************************
     * Perform matrix *
     * multiplication here *
     **************************/

    end1 = time(NULL);
    end2 = clock();

    printf("Wall time taken was %lf\nCPU time taken was %lf\n",
           difftime(end1, start1), ((double)(end2-start2))/CLOCKS_PER_SEC);

    for(int i=0; i<n; i++) {
        free(a[i]);
        free(b[i]);
        free(c[i]);
    }

    free(a);
    free(b);
    free(c);

    return 0;
}
