HOMEWORK 6 CONTEST: INVERSE WORD SEARCH


NAME:  < insert name >


OPTIMIZATIONS:
What did you do?



TEST CASE SUMMARY:
How did your program perform on the different test cases?  Summarize
the running times.  (It's ok if it didn't finish the harder examples.)
What new test cases did you create and how did it perform on those
tests?





