
    </div>
    <div id="footer">
      Introduction to Information Technology 2014, Rensselaer Polytechnic Institute
    </div>
  </body>
</html>

