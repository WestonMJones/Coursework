This lab was pretty easy.

Had we been given more directionas to what properties to include with each entry, it might have taken a bit more
research to figure out the proper specifications for each XML format, but as it was, this wasn't too challenging.

The templates and included resources did a good job of explaining what formats to follow and I like how the validator
would offer suggestions to help you fix your invalid code.


Link: https://afsws.rpi.edu/AFS/home/08/jonesw3/public_html/iit/resources/pages/projects.html