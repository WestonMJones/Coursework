I found that putting everything in divs and giving those divs IDs/Class Names
was helpful -- even if I didn't actually end up applying specific CSS to those
divs. It helped me organize my HTML a bit better and it'll be nice to have it there if I ever come
back to this resume and want to add some addition styles.

I unfortunately was unable to get some of my headers vertically aligned to
be centered relative to their associated graphic. I feel like I could
do this if I were allowed to put everything in table cells, but nevertheless, this
was a nice exercise in getting me more familiar with float properties.